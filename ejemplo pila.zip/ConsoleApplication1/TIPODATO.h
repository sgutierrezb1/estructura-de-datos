#pragma once
class TIPODATO
{
public:
	int id;
	string descripcion;
public:
	TipoDato(void);
	~tipodato(void)
		void set_tipodato(int id, string desc);

};

